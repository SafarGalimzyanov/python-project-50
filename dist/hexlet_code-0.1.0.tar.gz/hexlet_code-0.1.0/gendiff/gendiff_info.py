POS_ARGS = {'first_arg': 'first_file', 'second_arg': 'second_file'}

DESCRIPTION = f'Compares two configuration files and shows a difference.'

FLAG_H_DESC = 'show this help message and exit'

FLAG_H_MESSAGE = 'Compares two configurations'
