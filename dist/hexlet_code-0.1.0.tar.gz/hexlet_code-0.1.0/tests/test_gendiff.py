import pytest
from gendiff.gendiff import generate_diff as g_d


#def test_generate_diff_boundary_values(file1_path, file2_path):
    #with open(file1_path, 'r') as f1, open(file2_path, 'r') as f2:

print(g_d('tests/fixtures/file1.json', 'tests/fixtures/file2.json'))
